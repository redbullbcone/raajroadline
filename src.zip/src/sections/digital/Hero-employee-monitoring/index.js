export { default } from "./HeroEmployeeMonitoring";
