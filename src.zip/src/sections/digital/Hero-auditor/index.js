export { default } from "./HeroSectionAuditor";
