export { default } from "./ContentSectionTwo";

