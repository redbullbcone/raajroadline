export { default } from "./FooterSix";
