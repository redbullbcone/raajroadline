
export { default } from "./BlogDetails";
