export {default as AboutSection } from "./About"
export {default as ServiceSection } from "./Services"
export {default as JobSection } from "./Job"