export { default } from "./PromoSection";

