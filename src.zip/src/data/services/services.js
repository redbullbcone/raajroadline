const ServiceData = {
    services: [
        {
          id:"ss1",
          image:"image/home-services/business-icon-1.svg",
          // icon:"fa fa-file-invoice",
          title: "AI SEO Auditor & ",
          title2:"Freelancer Recommendation",
          // text: "There are many variations passages of Lorem lpsum majority, some words don’t look believable if you are going to use.",
          // iconBackground:"#0041ff"
        },
        {
          id:"ss2",
          // icon:"fa fa-bell",
          image:"image/home-services/business-icon-2.svg",
          title: "Online Marketing",
          title2:" Budget Optimization",
          // text:
          //   "There are many variations passages of Lorem lpsum majority, some words don’t look believable if you are going to use.",
          //   iconBackground:"#ff1e38"
        },
        {
          id:"ss3",
          // icon:"fa fa-bell",
          image:"image/home-services/business-icon-3.svg",
          title: "Freelancer & Employee",
          title2:" Monitoring",

          // text:
          //   "There are many variations passages of Lorem lpsum majority, some words don’t look believable if you are going to use.",
          //   iconBackground:"#fcdc00"
        },
        {
          // id:"ss4",
          // icon:"fa fa-headphones",
          image:"image/home-services/AML&KYC.svg",
          title: "Freelancer Fraud",
          title2: "Detection",

          // text:
          //   "There are many variations passages of Lorem lpsum majority, some words don’t look believable if you are going to use.",
          //   iconBackground:"#ff5200"
        },
        {
          id:"ss5",
          // icon:"fa fa-envelope",
          image:"image/home-services/business-icon-5.svg",
          title: "Easy International",
          title2:"Payment Processing",
          // text:"There are many variations passages of Lorem lpsum majority, some words don’t look believable if you are going to use.",
          //   iconBackground:"#1de2cf"
        },
        {
          id:"ss6",
          // icon:"fa fa-layer-group",
          image:"image/home-services/business-icon-6.svg",
          title: "Add College-Educated",
          title2:"interns to your Team"
          // text:
          //   "There are many variations passages of Lorem lpsum majority, some words don’t look believable if you are going to use.",
          //   iconBackground:"#6001d3"
        }
    ]
}
  export default ServiceData;