
const TestimonialData = {
  testimonial: [
    {
      id: "ts1",
      image: "image/it-services/user-circle-1.png",
      icon: "fa fa-quote-left",
      userName: "Design & Vreatives",
      userPosition: "One year with us",
      text: "consetetur sadipscing elltr, sed dlam nonumy elrmod tempor invidunt ut labore et dolore magna allquyamerat, sed dlam voluptua.",
    },
    {
      id: "ts2",
      image: "image/it-services/user-circle-2.png",
      icon: "fa fa-quote-left",
      userName: "John Doe",
      userPosition: "One year with us",
      text: "consetetur sadipscing elltr, sed dlam nonumy elrmod tempor invidunt ut labore et dolore magna allquyamerat, sed dlam voluptua.",
    },
    {
      id: "ts3",
      image: "image/it-services/user-circle-3.png",
      icon: "fa fa-quote-left",
      userName: "Charles Patterson",
      userPosition: "One year with us",
      text: "consetetur sadipscing elltr, sed dlam nonumy elrmod tempor invidunt ut labore et dolore magna allquyamerat, sed dlam voluptua.",
    },
    {
      id: "ts3",
      image: "image/it-services/user-circle-4.png",
      icon: "fa fa-quote-left",
      userName: "Charles Patterson",
      userPosition: "One year with us",
      text: "consetetur sadipscing elltr, sed dlam nonumy elrmod tempor invidunt ut labore et dolore magna allquyamerat, sed dlam voluptua.",
    },
    {
      id: "ts3",
      image: "image/it-services/user-circle-5.png",
      icon: "fa fa-quote-left",
      userName: "Charles Patterson",
      userPosition: "One year with us",
      text: "consetetur sadipscing elltr, sed dlam nonumy elrmod tempor invidunt ut labore et dolore magna allquyamerat, sed dlam voluptua.",
    },
    {
      id: "ts3",
      image: "image/it-services/user-circle-6.png",
      icon: "fa fa-quote-left",
      userName: "Charles Patterson",
      userPosition: "One year with us",
      text: "consetetur sadipscing elltr, sed dlam nonumy elrmod tempor invidunt ut labore et dolore magna allquyamerat, sed dlam voluptua.",
    },
  ],
};
export default TestimonialData;
