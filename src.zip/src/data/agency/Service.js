
const ServiceData = [

        {
          id:"as1",
          image:"image/marketplace/icon11.png",
          title: "Post a ",
          title2:"Requirement",
          text:
            "Stay on top of your task lists and stayin touch with what's happening",
        },
        {
          id:"as2",
          image:"image/marketplace/icon12.png",
          title: "Our AI will recommend you vendors with the skillset and reputation you need",
          text:
            "Stay on top of your task lists and stayin touch with what's happening",
        },
        {
          id:"as3",
          image:"image/marketplace/icon13.png",
          title: "Browse video profiles and portfolios for easy evaluation",
          text:
            "Stay on top of your task lists and stay in touch with what's happening",
        },
        {
          id:"as4",
          image:"image/marketplace/icon14.png",
          title: "Invite & Hire, or ",
          title2:"Receive Offers",
          text:
            "Stay on top of your task lists and stayin touch with what's happening",
        },
        {
          id:"as5",
          image:"image/marketplace/icon15.png",
          title: "Track Work Progress with",
          title2:"our job monitoring tools",
          text:
            "Stay on top of your task lists and stay in touch with what's happening",
        },
  
      ]
  export default ServiceData;