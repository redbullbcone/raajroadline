const ServiceData = [
        {
          id:"is1",
          icon:" fa-earth-americas",
          title: "Product Management",
          text: "50 availabe vacancy",
          iconBackground:"#1de2cf"
        },
        {
          id:"is2",
          icon:"fas fa-layer-group",
          title: "Web & Mobile Development",
          text:"50 availabe vacancy",
          iconBackground:"#494ca2"
        },
        {
          id:"is3",
          icon:"fas fa-headphones",
          title: "Customer Support",
          text: "50 availabe vacancy",
          iconBackground:"#0f89ff"
        },
        {
          id:"is4",
          icon:"fas fa-bell",
          title: "Human Resources",
          text: "50 availabe vacancy",
          iconBackground:"#ff5722"
        },
    ]
  export default ServiceData;