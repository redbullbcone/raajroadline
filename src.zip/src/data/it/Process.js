// import Images from "~data/imageImports";
const ProcessData = [
      {
        id:"ps1",
        icon: "1",
        iconBackground: "#5034fc",
        title: "General Concept",
        text:
          "Part of what Adobe does is advise customers about how to transform, to be more",
      },
      {
        id:"ps2",
        icon: "2",
        iconBackground:"#ef4339",
        title: "Post Product",
        text:
          "Part of what Adobe does is advise customers about how to transform, to be more",
      },
      {
        id:"ps3",
        icon: "3",
        iconBackground:"#0abfbc",
        title: "Design Process",
        text:
          "Part of what Adobe does is advise customers about how to transform, to be more",
      },
  ]
  export default ProcessData;