import BlogsImg1 from "~image/blogs/blog-post-1.png";
import BlogsImg2 from "~image/blogs/blog-post-2.png";
import BlogsImg3 from "~image/blogs/blog-post-3.png";
import BlogsImg4 from "~image/blogs/blog-post-4.png";
import BlogsImg5 from "~image/blogs/blog-post-5.png";
import BlogsImg6 from "~image/blogs/blog-post-6.png";
import BlogsImg7 from "~image/blogs/blog-post-7.png";
const BlogData = [
  {
    id: "bg1",
    image: BlogsImg2,
    badge: "Gadgets",
    date: "01 June, 2020",
    title:
      "We can blend colors multiple<br class='d-none d-xs-block'> ways, the most common",
    user: "By George Lee",
    Like: "21K",
    commentCount: " 305",
  },
  {
    id: "bg2",
    image: BlogsImg3,
    badge: "Gadgets",
    date: "01 June, 2020",
    title:
      "We can blend colors multiple<br class='d-none d-xs-block'> ways, the most common",
    user: "By George Lee",
    Like: "21K",
    commentCount: " 2",
  },
  {
    id: "bg3",
    image: BlogsImg4,
    badge: "Gadgets",
    date: "01 June, 2020",
    title:
      "We can blend colors multiple<br class='d-none d-xs-block'> ways, the most common",
    user: "By George Lee",
    Like: "21K",
    commentCount: " 3",
  },
  {
    id: "bg4",
    image: BlogsImg5,
    badge: "Gadgets",
    date: "01 June, 2020",
    title:
      "We can blend colors multiple<br class='d-none d-xs-block'> ways, the most common",
    user: "By George Lee",
    Like: "21K",
    commentCount: " 3",
  },
  {
    id: "bg5",
    image: BlogsImg6,
    badge: "Gadgets",
    date: "01 June, 2020",
    title:
      "We can blend colors multiple<br class='d-none d-xs-block'> ways, the most common",
    user: "By George Lee",
    Like: "21K",
    commentCount: " 3",
  },
  {
    id: "bg6",
    image: BlogsImg7,
    badge: "Gadgets",
    date: "01 June, 2020",
    title:
      "We can blend colors multiple<br class='d-none d-xs-block'> ways, the most common",
    user: "By George Lee",
    Like: "21K",
    commentCount: " 3",
  },
];
export default BlogData;
