// const ServiceData =[
//         {
//           id:"ss1",
//           icon:"fas fa-layer-group",
//           title: "Marketplace",
//           text: "Get connected to Global Freelancers, Agencies, & Interns.",
//           iconBackground:"#6001d3"
//         },
//         {
//           id:"ss2",
//           icon:"fas fa-bell",
//           title: "AI Auditor",
//           text: "All your Marketing Data, Analytics, and AI in One Dashboard",
//           iconBackground:"#fd346e"
//         },
//         {
//           id:"ss3",
//           icon:"fas fa-envelope",
//           title:"Prepaid Virtual Cards",
//           text:"Earn up to 1.5% Cashback on Online Marketing Spend with MRKT365",
//           iconBackground:"#1de2cf"
//         },
//         {
//           id:"ss4",
//           icon:"fas fa-chart-pie",
//           title: "Employee Monitoring",
//           text:
//             "Bring out the Best in your Remote Team with Productivity Tools that gets Work done.",
//             iconBackground:"#ffd700"
//         }
//     ]
  // export default ServiceData;