const TestimonialPosts = [
    {
    text:"There are many variations passages of Lorem lpsum available, but the majority have suffered alteration in some form, by injected or randomised.",
    userImage:"image/it-services/user-circle-1.png",
    userName:"Gary Simon",
    userPosition:"Sholl’s Colonial Cafeteria"
},
{
    text:"There are many variations passages of Lorem lpsum available, but the majority have suffered alteration in some form, by injected or randomised.",
    userImage:"image/it-services/user-circle-2.png",
    userName:"Karla Lynn",
    userPosition:"Sholl’s Colonial Cafeteria"
},
{
    text:"There are many variations passages of Lorem lpsum available, but the majority have suffered alteration in some form, by injected or randomised.",
    userImage:"image/it-services/user-circle-3.png",
    userName:"Stella Jennifer",
    userPosition:"Sholl’s Colonial Cafeteria"
},
{
    text:"There are many variations passages of Lorem lpsum available, but the majority have suffered alteration in some form, by injected or randomised.",
    userImage:"image/it-services/user-circle-4.png",
    userName:"Gary Simon",
    userPosition:"Sholl’s Colonial Cafeteria"
},
{
    text:"There are many variations passages of Lorem lpsum available, but the majority have suffered alteration in some form, by injected or randomised.",
    userImage:"image/it-services/user-circle-5.png",
    userName:"Karla Lynn",
    userPosition:"Sholl’s Colonial Cafeteria"
},
{
    text:"There are many variations passages of Lorem lpsum available, but the majority have suffered alteration in some form, by injected or randomised.",
    userImage:"image/it-services/user-circle-6.png",
    userName:"Stella Jennifer",
    userPosition:"Sholl’s Colonial Cafeteria"
}
]

export default TestimonialPosts;